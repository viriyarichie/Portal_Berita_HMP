import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daftar-berita',
  templateUrl: './daftar-berita.page.html',
  styleUrls: ['./daftar-berita.page.scss'],
  standalone: false,
})
export class DaftarBeritaPage implements OnInit {
  constructor() {}

  ngOnInit() {}
}
