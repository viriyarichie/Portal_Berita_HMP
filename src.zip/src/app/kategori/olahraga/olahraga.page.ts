import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-olahraga',
  templateUrl: './olahraga.page.html',
  styleUrls: ['./olahraga.page.scss'],
  standalone: false,
})
export class OlahragaPage implements OnInit {
  constructor() {}

  ngOnInit() {}
}
