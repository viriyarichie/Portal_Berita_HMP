import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saham',
  templateUrl: './saham.page.html',
  styleUrls: ['./saham.page.scss'],
  standalone: false,
})
export class SahamPage implements OnInit {
  constructor() {}

  ngOnInit() {}
}
